> # Update Information (Latest listed first)
> ### v1.0.6
> - Ashlands update
> ### v1.0.5
> - Bug fix when using BeastTribes
> ### v1.0.4
> - Update for Valheim 0.217.22
> ### v1.0.3
> - Fixed issues with picking up items in Mistlands
> ### v1.0.2
> - Update ServerSync internally
> ### v1.0.1
> - Fix bug with armor durability not working
> ### v1.0.0
> - Initial Release